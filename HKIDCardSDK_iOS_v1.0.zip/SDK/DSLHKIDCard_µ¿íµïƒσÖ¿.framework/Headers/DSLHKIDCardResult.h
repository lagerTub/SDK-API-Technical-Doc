//
//  DSLHKIDCardResult.h
//  DSLHKIDCardDemo
//
//  Created by chentao on 2018/7/5.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DSLHKIDCardResult : NSObject

// 是否识别成功
@property(nonatomic,assign)BOOL success;

//
//1.first:表示当前返回第一个动作的静态证件图片;
//2.exposure-start:表示当前返回开始打开闪光灯;
//3.exposure:表示当前返回反光过大，重新开始识别;
//4.overspeed:表示当前返回移动速度太快，重新开始识别;
@property(nonatomic,copy)NSString *message;

// 校验数据
@property(nonatomic,copy)NSString *delta;

// 图片数据
//1.当success为NO,message为first，则数组的第一张图片为静态证件图片
//2.当success为YES,则数组的第一张图片为静态证件图片，最后一张为人脸比对的证件头像图片
@property(nonatomic,copy)NSArray<NSData *> *imageDataArray;

@end
