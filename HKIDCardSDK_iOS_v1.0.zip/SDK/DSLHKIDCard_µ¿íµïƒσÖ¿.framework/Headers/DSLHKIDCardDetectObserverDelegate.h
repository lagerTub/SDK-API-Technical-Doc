//
//  DSLHKIDCardDetectObserverDelegate.h
//  DSLHKIDCard
//
//  Created by chentao on 2018/7/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DSLHKIDCardResult.h"
#import "DSLHKIDCardNextOperation.h"
@protocol DSLHKIDCardDetectObserverDelegate <NSObject>

@optional

/**
 操作提示

 @param command 具体参考DSLHKIDCardNextOperation类说明
 */
-(void)didUpdateOperationCommand:(DSLHKIDCardNextOperation *)command;

/**
 识别结果

 @param result 具体参考DSLHKIDCardResult类说明
 */
-(void)didDetectResult:(DSLHKIDCardResult *)result;

@end
