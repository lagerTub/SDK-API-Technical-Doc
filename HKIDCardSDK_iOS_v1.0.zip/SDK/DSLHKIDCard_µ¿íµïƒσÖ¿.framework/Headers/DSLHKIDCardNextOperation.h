//
//  DSLHKIDCardNextOperation.h
//  DSLHKIDCard
//
//  Created by chentao on 2018/7/9.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,DSLHKIDCardOperationStatus){
    DSLHKIDCardOperation_BEGIN, // 开始识别
    DSLHKIDCardOperation_ORTH, // 正对识别完成
    DSLHKIDCardOperation_UP,  // 向上翻转识别完成
    DSLHKIDCardOperation_DOWN, // 向下翻转识别完成
    DSLHKIDCardOperation_COMPLETE, //识别完成
    DSLHKIDCardOperation_NOCARD,    //请对准身份证件
    DSLHKIDCardOperation_EXPOSURE,  //光线太亮
    DSLHKIDCardOperation_OTHER      //其他
};

@interface DSLHKIDCardNextOperation : NSObject

// 当前识别转态
@property(nonatomic,assign)DSLHKIDCardOperationStatus currentStatus;

// 下一步操作提示  当currentStatus 为DSLHKIDCardOperation_DOWN | DSLHKIDCardOperation_COMPLETE时为空
@property(nonatomic,copy)NSString *nextOperationHint;

@end
