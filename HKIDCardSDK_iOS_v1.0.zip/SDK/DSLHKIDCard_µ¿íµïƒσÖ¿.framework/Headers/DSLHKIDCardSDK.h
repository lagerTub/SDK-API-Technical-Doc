//
//  DSLHKIDCardSDK.h
//  DSLHKIDCardDemo
//
//  Created by chentao on 2018/7/5.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreMedia/CoreMedia.h>
@protocol DSLHKIDCardDetectObserverDelegate;

@interface DSLHKIDCardSDK : NSObject

/**
 开始检测
 */
+(void)startDetect;

/**
 识别中退出重置状态
 */
+(void)resetStatus;

/**
 回调对象注册接口
 
 @param observer 回调对象
 */
+(void)registerObserver:(id<DSLHKIDCardDetectObserverDelegate>)observer;

/**
 回调对象注销接口
 
 @param observer 回调对象
 */
+(void)unregisterObserver:(id<DSLHKIDCardDetectObserverDelegate>)observer;

/**
 图片识别传入
 
 @param imageData 图片
 */
+(void)addDetectBufferData:(NSData *)imageData;


/**
 设置证件类型
 
 @param isNewIDCard YES:新证件；NO:老证件
 */
+(void)setIDCardType:(BOOL)isNewIDCard;

/**
 获取当前SDK版本号
 
 @return 当前版本号
 */
+(NSString *)getVersion;

@end
