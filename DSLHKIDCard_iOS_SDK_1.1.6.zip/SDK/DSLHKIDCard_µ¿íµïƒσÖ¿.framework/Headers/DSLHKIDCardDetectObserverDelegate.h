//
//  DSLHKIDCardDetectObserverDelegate.h
//  DSLHKIDCard
//
//  Created by chentao on 2018/7/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DSLHKIDCardResult.h"
#import "DSLHKIDCardNextOperation.h"

@protocol DSLHKIDCardDetectObserverDelegate <NSObject>

@optional

/**
 必须实现这个代理，当前操作动作返回
 
 @param command DSLHKIDCardNextOperation对象,其中的操作动作对应如下
 DSLHKIDCardOperation_BEGIN, // 开始识别
 DSLHKIDCardOperation_ORTH, // 正对识别完成
 DSLHKIDCardOperation_UP,  // 向上翻转识别完成
 DSLHKIDCardOperation_DOWN, // 向下翻转识别完成
 DSLHKIDCardOperation_COMPLETE, //识别完成
 DSLHKIDCardOperation_NOCARD,    //请对准身份证件
 DSLHKIDCardOperation_EXPOSURE,  //光线太亮
 DSLHKIDCardOperation_RESET,      //复位(把证件正面放置在框内)
 DSLHKIDCardOperation_FAR,        //距离过远(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
 DSLHKIDCardOperation_NEAR,       //距离过近(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
 DSLHKIDCardOperation_OVERSPEED,   //转速过快(注意: 仅仅是提示，与动作流程无关，当转速恢复正常后，需要继续显示当前动作的提示语)
 DSLHKIDCardOperation_VALID        //当【距离过远，距离过近，转速过快】恢复正常时，会发送VALID消息，UI需要恢复显示当前动作的提示语
 */
-(void)didUpdateOperationCommand:(DSLHKIDCardNextOperation *)command;

/**
 必须实现这个代理，识别结果返回

 @param result 识别结果返回,其中各种结果对应的code及message如下
 retCode和message对应的值如下:
 
 retCode     message             说明描述
 0                               识别成功
 1           first               当前返回第一个动作的静态证件图片
 2           exposure            表示当前返回反光过强，重新开始识别;【当前已废弃】
 3           overspeed           表示当前返回移动速度太快，重新开始识别;【当前已废弃】
 4           lost                目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
 5           overtime            识别超时,超时时间可以设置
 */
-(void)didDetectResult:(DSLHKIDCardResult *)result;

@end
