//
//  DSLHKIDCardNextOperation.h
//  DSLHKIDCard
//  识别过程中，当前操作动作返回提示
//  Created by chentao on 2018/7/9.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,DSLHKIDCardOperationStatus){
    DSLHKIDCardOperation_BEGIN, // 开始识别
    DSLHKIDCardOperation_ORTH, // 正对识别完成
    DSLHKIDCardOperation_UP,  // 向上(或者向右)翻转识别完成
    DSLHKIDCardOperation_DOWN, // 向下(或者向左)翻转识别完成
    DSLHKIDCardOperation_COMPLETE, //识别完成
    DSLHKIDCardOperation_NOCARD,    //请对准身份证件
    DSLHKIDCardOperation_EXPOSURE,  //光线太亮
    DSLHKIDCardOperation_RESET,      //复位(请缓慢把证件复位，正面放置在框内)，2018版证件当向右翻动作完成及2003版证件当向上翻动作完成时会收到
    DSLHKIDCardOperation_FAR,        //距离过远(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_NEAR,       //距离过近(注意: 仅仅是提示，与动作流程无关，当距离恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_OVERSPEED,   //转速过快(注意: 仅仅是提示，与动作流程无关，当转速恢复正常后，需要继续显示当前动作的提示语)
    DSLHKIDCardOperation_VALID        //当【距离过远，距离过近，转速过快】恢复正常时，会发送VALID消息，UI需要恢复显示当前动作的提示语
};

@interface DSLHKIDCardNextOperation : NSObject

// 当前识别状态
@property(nonatomic,assign)DSLHKIDCardOperationStatus currentStatus;

// 为nil,可以不关注; 提示语为了方便管理和支持多语言统一放到Localizable.strings文件，在外部配置
@property(nonatomic,copy)NSString *nextOperationHint;

@end
