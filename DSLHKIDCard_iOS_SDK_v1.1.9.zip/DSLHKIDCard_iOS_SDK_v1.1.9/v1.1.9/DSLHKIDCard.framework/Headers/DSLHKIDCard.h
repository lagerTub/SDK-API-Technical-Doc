//
//  DSLHKIDCard.h
//  DSLHKIDCard
//
//  Created by chentao on 2018/7/6.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DSLHKIDCard.
FOUNDATION_EXPORT double DSLHKIDCardVersionNumber;

//! Project version string for DSLHKIDCard.
FOUNDATION_EXPORT const unsigned char DSLHKIDCardVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DSLHKIDCard/PublicHeader.h>

//#import "DSLHKIDCardVerifyResult.h"

#import "DSLHKIDCardDetectObserverDelegate.h"

//#import "DSLHKIDCardManager.h"

#import "DSLHKIDCardResult.h"

#import "DSLHKIDCardSDK.h"










