//
//  DSLHKIDCardResult.h
//  DSLHKIDCardDemo
//
//  Created by chentao on 2018/7/5.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DSLHKIDCardResult : NSObject

// 是否识别成功
@property(nonatomic,assign)BOOL success;

/**
 retCode和message对应的值如下:
 
    retCode     message             说明描述

    0                               识别成功
    1           first               当前返回第一个动作的静态证件图片
    2           exposure            表示当前返回反光过强，重新开始识别;
    3           overspeed           表示当前返回移动速度太快，重新开始识别;
    4           lost                目标(证件)丢失,在识别证件过程中，发现某些证件特征持续捕获不到导致识别失败
    5           overtime            识别超时,超时时间可以设置
 */
@property(nonatomic,copy)NSString *message;
@property(nonatomic, assign) int retCode;

// 校验数据,预留字段，目前不需要处理
@property(nonatomic,copy)NSString *delta;

// 图片数据
//1.当success为NO,retCode为1时，则数组的第一张图片为静态证件图片，其他情况为空
//2.当success为YES,retCode为0时,则数组的第一张图片为静态证件图片，最后一张为人脸比对的证件头像图片
@property(nonatomic,copy)NSArray<NSData *> *imageDataArray;

@end
