//
//  DSLHKIDCardNextOperation.h
//  DSLHKIDCard
//  识别过程中，当前操作动作返回提示
//  Created by chentao on 2018/7/9.
//  Copyright © 2018年 chentao. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger,DSLHKIDCardOperationStatus){
    DSLHKIDCardOperation_BEGIN, // 开始识别
    DSLHKIDCardOperation_ORTH, // 正对识别完成
    DSLHKIDCardOperation_UP,  // 向上翻转识别完成
    DSLHKIDCardOperation_DOWN, // 向下翻转识别完成
    DSLHKIDCardOperation_COMPLETE, //识别完成
    DSLHKIDCardOperation_NOCARD,    //请对准身份证件
    DSLHKIDCardOperation_EXPOSURE,  //光线太亮
    DSLHKIDCardOperation_RESET      //复位(把证件正面放置在框内)
};

@interface DSLHKIDCardNextOperation : NSObject

// 当前识别状态
@property(nonatomic,assign)DSLHKIDCardOperationStatus currentStatus;

// 为nil,可以不关注; 提示语为了方便管理和支持多语言统一放到Localizable.strings文件，在外部配置
@property(nonatomic,copy)NSString *nextOperationHint;

@end
